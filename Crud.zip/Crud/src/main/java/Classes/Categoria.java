
package Classes;

import interfaces.Crud;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;


public class Categoria implements Crud{
   int id;
   String nome;
   
   public Categoria(int id){
    if(id>0){
        String sql = "SELECT*FROM Categorias WHERE id = ?";
        try{
            Connection con = DB.conexao();
        
     PreparedStatement stmt = con.prepareCall(sql);
     stmt.setInt(1,id);
     ResultSet registro = stmt.executeQuery();
        
        while(registro.next()){
         this.setid();
         this.setnome();
     }
        
        }catch(SQLException e){
    System.out.println("Erro na consulta do produto:"+e.toString());     
         } catch (ClassNotFoundException ex) {
         Logger.getLogger(Produto.class.getName()).log(Level.SEVERE, null, ex);
     }
    }   
   }
   
   //ID
   public int getid(){
       return id;
   }
   public void setid(){
       this.id = id;
   }

  
   //NOME
   public String getNome(){
       return nome;
   }
   public void setnome(){
       this.nome = nome;
   }

    @Override
    public void adicionar() {
        
    }

    @Override
    public void listar() {
       
    }

    @Override
    public void atualizar() {
        
    }

    @Override
    public void deletar() {
        
    }
   
   
   
}
