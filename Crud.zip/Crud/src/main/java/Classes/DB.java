
package Classes;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class DB {
    public static String servidor = "127.0.0.1";
     public static String usuario = "root";
     public static String senha = "";
     public static String nome_banco = "crud";
     
     
     public static Connection conexao() throws ClassNotFoundException{
         Connection conexao = null;
         try{
             Class.forName("com.mysql.cj.jdbc.Drive");
             conexao = DriverManager.getConnection(
             "jdbc:mysql://"+servidor+"/"+nome_banco+"",usuario,senha
             );
             
         }catch(SQLException e){
             System.out.println("erro de conexão"+ e.toString());
         }
         return conexao;
     }
}
