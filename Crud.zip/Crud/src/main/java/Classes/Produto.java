
package Classes;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;


public class Produto {
 int id;
 int categoria_id;
 String Nome;
 double preco;
 int quantidade;
  
 public Produto(int id){
 if(id>0){
     String sql = "SELECT*FROM produtos WHERE id = ?";
 try{
     Connection con = DB.conexao();
     PreparedStatement stmt = con.prepareCall(sql);
     stmt.setInt(1,id);
     ResultSet registro = stmt.executeQuery();
     
     while(registro.next()){
         this.setNome(Nome);
         this.setcategoria_id(categoria_id);
         this.setid(id);
         this.setpreco(preco);
         this.setquantidade(quantidade);
     }
     
 }catch(SQLException e){
    System.out.println("Erro na consulta do produto:"+e.toString());     
         } catch (ClassNotFoundException ex) {
         Logger.getLogger(Produto.class.getName()).log(Level.SEVERE, null, ex);
     }
 
 }
 
}
 


//ID
 public int getid(){
       return id;
   }
   public void setid(int id){
       this.id =id;
   }
   
   
 //categoria_id
    public int gecategoria_id(){
       return categoria_id;
   }
   public void setcategoria_id(int categoria_id){
       this.categoria_id =categoria_id;
   }
   
    public int getcategoria_id(){
       return categoria_id;
   }
    
    
    //Nome
   public void setNome(String Nome){
       this.Nome =Nome;
   }
   
    public String getNome(){
       return Nome;
   }
    
    
    //preco
   public void setpreco(double preco){
       this.preco =preco;
   }
   
    public double getpreco(){
       return preco;
   }
   
    
    //quantidade
     public void setquantidade(int quantidade){
       this.quantidade =quantidade;
   }
   
    public int getquantidade(){
       return quantidade;
   }
 
 
 
 
    
}
