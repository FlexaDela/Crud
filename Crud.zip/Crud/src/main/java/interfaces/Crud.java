
package interfaces;


public interface Crud {
    public void adicionar();
    public void listar();
    public void atualizar();
    public void deletar();
    
}
