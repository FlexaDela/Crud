
import Classes.Categoria;
import Classes.Produto;

public class Crud {

    public static void main(String[] args) throws Exception{
     Categoria cat1 = new Categoria(1);
        System.out.println(cat1.getNome());
        System.out.println(cat1.getid());
        System.out.println(cat1.getClass());
       
 Produto p1 = new Produto(2);
    System.out.println(p1.getNome());
    System.out.println(p1.gecategoria_id());
    System.out.println(p1.getid());
    System.out.println(p1.getpreco());
    System.out.println(p1.getquantidade());
 
        
        
    }
}
