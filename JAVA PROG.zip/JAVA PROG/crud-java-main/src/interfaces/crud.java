package interfaces;

import java.util.ArrayList;

public interface crud {
    public void         adicionar();
    public ArrayList    listar();
    public void         atualizar();
    public void         deletar();
}
