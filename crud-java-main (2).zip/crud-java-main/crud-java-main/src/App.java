import classes.Categoria;
import classes.Produto;

public class App {
    public static void main(String[] args) throws Exception {
        
        // CADASTRAR CATEGORIA
        Categoria categoria = new Categoria(0);
         categoria.setNome("Categoria Batata");
         categoria.adicionar();

         //BUSCAR CATEGORIA
         Categoria Categoria = new Categoria(2);
         System.out.println(Categoria.getNome());

        // BUSCAR PRODUTO
         Produto produto = new Produto(2);
         System.out.println(produto.getNome());
    }
}
